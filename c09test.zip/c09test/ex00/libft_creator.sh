# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    libft_creator.sh                                   :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: wngui <marvin@42.fr>                       +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2023/07/03 13:36:06 by wngui             #+#    #+#              #
#    Updated: 2023/07/03 13:36:11 by wngui            ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

# Remove the existing libft.a file
rm -f libft.a

# Find all .c files in the current directory and its subdirectories,
# then compile them using gcc with specified warnings enabled
find . -name "*.c" -type f -exec gcc -Wall -Werror -Wextra -c {} \;

# Create a new static library file named libft.a
ar rc libft.a *.o

# Delete all .o files that were created during the compilation process
find . -name "*.o" -type f -delete

